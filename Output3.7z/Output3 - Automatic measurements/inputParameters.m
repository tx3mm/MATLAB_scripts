function [freqMHz] = inputParameters() %, VCC, VIO, duty
freqMHz = input('Enter test frequency (MHz): ');
% VIO = input('Enter VIO value (V): ');
% VIO = num2str(VIO);
% if strfind(VIO, '.')
%    VIO = strrep(VIO, '.', ',');
% end
% VCC = input('Enter VCC value (V): ');
% VCC = num2str(VCC);
% if strfind(VCC, '.')
%    VCC = strrep(VCC, '.', ',');
% end
% duty = input('Enter input Duty cycle (%): ');
end

